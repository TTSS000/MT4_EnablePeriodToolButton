﻿// dllmain.cpp : DLL アプリケーションのエントリ ポイントを定義します。
#include "pch.h"
#include <commctrl.h>
#include <stdio.h>

#define MT4_EXPFUNC __declspec(dllexport)

int g_count_called = 0;

void CreateConsole(void) {
  FILE* fp;
  AllocConsole();
  freopen_s(&fp, "CONOUT$", "w", stdout); /* 標準出力(stdout)を新しいコンソールに向ける */
  freopen_s(&fp, "CONOUT$", "w", stderr); /* 標準エラー出力(stderr)を新しいコンソールに向ける */


}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
      //CreateConsole();  // for debug console
      break;
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

BOOL CALLBACK ListChildWindows(HWND hWndChild, LPARAM lParam)
//WNDENUMPROC ListChildWindows(HWND hWndChild, LPARAM lParam)
{
  unsigned long pid;
  wchar_t c_WindowClassNameW[1024];
  char c_WindowClassNameC[1024];
  int i_CtrlID = 0;
  int numIcons = 0;
  HANDLE hProcess = NULL;
  TBBUTTON tbButton;
  g_count_called++;

  //GetClassNameW(hWndChild, c_WindowClassNameW, 1024);
  GetClassNameA(hWndChild, c_WindowClassNameC, 1024);
  //fprintf_s(stderr, "c_WindowClassNameW=%s\n", c_WindowClassNameW); /* 標準エラー出力 */
  //fprintf_s(stderr, "c_WindowClassNameC=%s\n", c_WindowClassNameC); /* 標準エラー出力 */
  //fprintf_s(stderr, "g_count_called=%d\n", g_count_called); /* 標準エラー出力 */
  GetWindowThreadProcessId(hWndChild, &pid);
  //fprintf_s(stderr, "pid=%d\n", pid); /* 標準エラー出力 */
  hProcess = OpenProcess(PROCESS_ALL_ACCESS, 0, pid);
  LPVOID  lpPointer = VirtualAllocEx(hProcess, 0, sizeof(TBBUTTON), MEM_COMMIT, PAGE_READWRITE);

  //if (0 <= lstrcmpW(c_WindowClassNameC, L"ToolbarWindow32")){
    if (0 <= lstrcmpA(c_WindowClassNameC, "ToolbarWindow32")) {
      // found the string
    i_CtrlID = GetDlgCtrlID(hWndChild);

    switch (i_CtrlID) {
    case 99:
    case 262:
    case 263:
    case 264:
    case 59420:
      //fprintf_s(stderr, "i_CtrlID=%d\n", i_CtrlID); /* 標準エラー出力 */
          //if (!IsWindowEnabled(hWndChild)) {
      //}
      numIcons = SendMessageA(hWndChild, TB_BUTTONCOUNT, 0, 0);
      for (int iButton = 0; iButton < numIcons; iButton++) {
        SendMessageA(hWndChild, TB_GETBUTTON, iButton, (LPARAM)lpPointer);
        ReadProcessMemory(hProcess, lpPointer , &tbButton, sizeof(tbButton), NULL);
        int command_id = tbButton.idCommand;
          if(!(tbButton.fsState & TBSTATE_ENABLED)){
            SendMessageA(hWndChild, TB_ENABLEBUTTON, command_id, 1);
          }
      }
      break;
    default:
      break;
    }
  }

  VirtualFreeEx(hProcess, lpPointer, sizeof(TBBUTTON), MEM_DECOMMIT);
  CloseHandle(hProcess);
  //EnumChildWindows(hWndChild, ListChildWindows, 0);

  return(true);

}

MT4_EXPFUNC BOOL __stdcall EnablePeriodToolButton(HWND hWndParent)
{
  if (hWndParent != NULL) {
    EnumChildWindows(hWndParent, ListChildWindows, 0);
  }
	return(true);
}